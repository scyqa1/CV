selRoi = 1
initial = 0
top_left= [160,213]
bottom_right = [320,426]
first_time = 1


