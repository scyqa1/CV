import cv2 as cv
import numpy as np
from numpy import *
import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QFileDialog, QMainWindow
from mainForm1 import Ui_MainWindow
import time

import globalVariables as gV
import random

import cmath
from calcOpticalFlowPyrLK import App


from PIL import ImageFont
from PIL import Image
from PIL import ImageDraw
import HyperLPRLite as pr
import importlib

import os 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

from skimage import transform
import matplotlib.pyplot as plt

def Mode1():
    # Parameters for Shi-Tomasi corner detection
    feature_params = dict(maxCorners = 300, qualityLevel = 0.2, minDistance = 2, blockSize = 7)
    # Parameters for Lucas-Kanade optical flow
    lk_params = dict(winSize = (15,15), maxLevel = 2, criteria = (cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03))
    # The video feed is read in as a VideoCapture object
    cap = cv.VideoCapture("a.mp4")
    # Variable for color to draw optical flow track
    color = (0, 255, 0)
    # ret = a boolean return value from getting the frame, first_frame = the first frame in the entire video sequence
    ret, first_frame = cap.read()
    # Converts frame to grayscale because we only need the luminance channel for detecting edges - less computationally expensive
    prev_gray = cv.cvtColor(first_frame, cv.COLOR_BGR2GRAY)
    # Finds the strongest corners in the first frame by Shi-Tomasi method - we will track the optical flow for these corners
    prev = cv.goodFeaturesToTrack(prev_gray, mask = None, **feature_params)
    # Creates an image filled with zero intensities with the same dimensions as the frame - for later drawing purposes
    mask = np.zeros_like(first_frame)


    while(cap.isOpened()):
        # ret = a boolean return value from getting the frame, frame = the current frame being projected in the video
        ret, frame = cap.read()
        if(ret==False):
            break
        # Converts each frame to grayscale - we previously only converted the first frame to grayscale
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        # Calculates sparse optical flow by Lucas-Kanade method
        next, status, error = cv.calcOpticalFlowPyrLK(prev_gray, gray, prev, None, **lk_params)
        # Selects good feature points for previous position
        good_old = prev[status == 1]
        # Selects good feature points for next position
        good_new = next[status == 1]
        # Draws the optical flow tracks
        for i, (new, old) in enumerate(zip(good_new, good_old)):
            # Returns a contiguous flattened array as (x, y) coordinates for new point
            a, b = new.ravel()
            # Returns a contiguous flattened array as (x, y) coordinates for old point
            c, d = old.ravel()
            # Draws line between new and old position with green color and 2 thickness
            mask = cv.line(mask, (a, b), (c, d), color, 2)
            # Draws filled circle (thickness of -1) at new position with green color and radius of 3
            frame = cv.circle(frame, (a, b), 3, color, -1)
        # Overlays the optical flow tracks on the original frame
        output = cv.add(frame, mask)
        # Updates previous frame
        prev_gray = gray.copy()
        # Updates previous good feature points
        prev = good_new.reshape(-1, 1, 2)
        # Opens a new window and displays the output frame
        cv.imshow("sparse optical flow", output)
        # Frames are read by intervals of 10 milliseconds. The programs breaks out of the while loop when the user presses the 'q' key
        if cv.waitKey(10) & 0xFF == ord('q'):
            break
    # The following frees up resources and closes all windows
    cap.release()
    cv.destroyAllWindows()


def Mode2():
    gV.selRoi = 0
    gV.top_left = [160, 213]
    gV.bottom_right = [320, 426]
    gV.first_time = 1
    # Parameters for lucas kanade optical flow
    lk_params = dict(winSize=(15, 15),
                     maxLevel=2,
                     criteria=(cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03))

    def findDistance(r1, c1, r2, c2):
        d = (r1 - r2) ** 2 + (c1 - c2) ** 2
        d = d ** 0.5
        return d

    # main function
    cv.namedWindow('tracker')

    cap = cv.VideoCapture("a.mp4")
    stopwhile=0
    while True:
        if(stopwhile==1):
            break
        while True:
            ret, frame = cap.read()
            if(ret==False):
                stopwhile=1
                break
            # -----Drawing Stuff on the Image
            cv.putText(frame, 'Press a to start tracking', (20, 50), cv.FONT_HERSHEY_SIMPLEX, 1, color=(60, 100, 75),
                        thickness=3)
            cv.rectangle(frame, (gV.top_left[1], gV.top_left[0]), (gV.bottom_right[1], gV.bottom_right[0]),
                          color=(100, 255, 100), thickness=4)

            # -----Finding ROI and extracting Corners
            frameGray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
            roi = frameGray[gV.top_left[0]:gV.bottom_right[0], gV.top_left[1]:gV.bottom_right[1]]  # selecting roi
            new_corners = cv.goodFeaturesToTrack(roi, 50, 0.01, 10)  # find corners

            # -----converting to complete image coordinates (new_corners)

            new_corners[:, 0, 0] = new_corners[:, 0, 0] + gV.top_left[1]
            new_corners[:, 0, 1] = new_corners[:, 0, 1] + gV.top_left[0]

            # -----drawing the corners in the original image
            for corner in new_corners:
                cv.circle(frame, (int(corner[0][0]), int(corner[0][1])), 5, (0, 255, 0))

            # -----old_corners and oldFrame is updated
            oldFrameGray = frameGray.copy()
            old_corners = new_corners.copy()

            cv.imshow('tracker', frame)

            if cv.waitKey(10) & 0xFF == ord('q'):
                break
            # The following frees up resources and closes all windows
        cap.release()
        cv.destroyAllWindows()

        # ----Actual Tracking-----
        while True:
            'Now we have oldFrame,we can get new_frame,we have old corners and we can get new corners and update accordingly'

            # read new frame and cvt to gray
            ret, frame = cap.read()
            if(ret==False):
                stopwhile=1
                break
            frameGray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
            # finding the new tracked points
            new_corners, st, err = cv.calcOpticalFlowPyrLK(oldFrameGray, frameGray, old_corners, None, **lk_params)

            # ---pruning far away points:
            # first finding centroid
            r_add, c_add = 0, 0
            for corner in new_corners:
                r_add = r_add + corner[0][1]
                c_add = c_add + corner[0][0]
            centroid_row = int(1.0 * r_add / len(new_corners))
            centroid_col = int(1.0 * c_add / len(new_corners))
            # draw centroid
            cv.circle(frame, (int(centroid_col), int(centroid_row)), 5, (255, 0, 0))
            # add only those corners to new_corners_updated which are at a distance of 30 or lesse
            new_corners_updated = new_corners.copy()
            tobedel = []
            for index in range(len(new_corners)):
                if findDistance(new_corners[index][0][1], new_corners[index][0][0], int(centroid_row),
                                int(centroid_col)) > 90:
                    tobedel.append(index)
            new_corners_updated = np.delete(new_corners_updated, tobedel, 0)

            # drawing the new points
            for corner in new_corners_updated:
                cv.circle(frame, (int(corner[0][0]), int(corner[0][1])), 5, (0, 255, 0))
            if len(new_corners_updated) < 10:
                print('OBJECT LOST, Reinitialize for tracking')
                break
            # finding the min enclosing circle
            ctr, rad = cv.minEnclosingCircle(new_corners_updated)

            cv.circle(frame, (int(ctr[0]), int(ctr[1])), int(rad), (0, 0, 255), thickness=5)

            # updating old_corners and oldFrameGray
            oldFrameGray = frameGray.copy()
            old_corners = new_corners_updated.copy()

            # showing stuff on video
            cv.putText(frame, 'Tracking Integrity : Excellent %04.3f' % random.random(), (20, 50),
                        cv.FONT_HERSHEY_SIMPLEX, 1, color=(200, 50, 75), thickness=3)
            cv.imshow('tracker', frame)

            if cv.waitKey(10) & 0xFF == ord('q'):
                break
    # The following frees up resources and closes all windows
            cap.release()
    cv.destroyAllWindows()


def Mode3():
    fontC = ImageFont.truetype("Font/platech.ttf", 14, 0)
    importlib.reload(sys)
    # sys.setdefaultencoding("utf-8")

    def drawRectBox(image,rect,addText):
        cv.rectangle(image, (int(rect[0]), int(rect[1])), (int(rect[0] + rect[2]), int(rect[1] + rect[3])), (0,0, 255), 2,cv.LINE_AA)
        cv.rectangle(image, (int(rect[0]-1), int(rect[1])-16), (int(rect[0] + 115), int(rect[1])), (0, 0, 255), -1,
                      cv.LINE_AA)
        img = Image.fromarray(image)
        draw = ImageDraw.Draw(img)
        draw.text((int(rect[0]+1), int(rect[1]-16)), addText, (255, 255, 255), font=fontC)
        imagex = np.array(img)
        return imagex


    # 测试结果 并可视化
    def visual_draw_position(grr):
        model = pr.LPR("model/cascade.xml","model/model12.h5","model/ocr_plate_all_gru.h5")
        for pstr,confidence,rect in model.SimpleRecognizePlateByE2E(grr):
            if confidence>0.7:
                grr = drawRectBox(grr, rect, pstr+" "+str(round(confidence,3)))
                print ("车牌号:")
                print (pstr)
                print ("置信度")
                print (confidence)
        return grr


    # The video feed is read in as a VideoCapture object
    cap = cv.VideoCapture("b.mp4")
    # ret = a boolean return value from getting the frame, first_frame = the first frame in the entire video sequence
    ret, first_frame = cap.read()
    # Converts frame to grayscale because we only need the luminance channel for detecting edges - less computationally expensive
    prev_gray = cv.cvtColor(first_frame, cv.COLOR_BGR2GRAY)
    # Creates an image filled with zero intensities with the same dimensions as the frame
    mask = np.zeros_like(first_frame)
    # Sets image saturation to maximum
    mask[..., 1] = 255

    while(cap.isOpened()):
        # ret = a boolean return value from getting the frame, frame = the current frame being projected in the video
        ret, frame = cap.read()
        # Converts each frame to grayscale - we previously only converted the first frame to grayscale
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        output = visual_draw_position(frame)
        # Opens a new window and displays frame
        cv.imshow("plate", output)

        prev_gray = gray
        # Frames are read by intervals of 1 millisecond. The programs breaks out of the while loop when the user presses the 'q' key
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv.destroyAllWindows()


def Mode4():
    lk_params = dict(winSize=(15, 15),
                     maxLevel=2,
                     criteria=(cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03))

    feature_params = dict(maxCorners=1000,
                          qualityLevel=0.1,
                          minDistance=7,
                          blockSize=7)

    video_src = "a.mp4"

    App(video_src).run()
    cv.destroyAllWindows()  


def Mode5():

    cap = cv.VideoCapture("a.mp4")

    i=0
    num=0
    number = 0

    ret, frame1 = cap.read()
    prvs = cv.cvtColor(frame1,cv.COLOR_BGR2GRAY)
    hsv = np.zeros_like(frame1)
    hsv[...,1] = 255

    def draw_flow(im, flow, step=1):
        h, w = im.shape[:2]
        y, x = mgrid[step / 2:h:step, step / 2:w:step].reshape(2, -1)
        x = x.astype('int64')
        y = y.astype('int64')
        fx, fy = flow[y, x].T
        for index in range(h*w):
            f.writelines([str(x[index]),' ',str(y[index]),' ',str(fx[index]),' ',str(fy[index]),'\n'])

        # create line endpoints
        lines = vstack([x, y, x + fx, y + fy]).T.reshape(-1, 2, 2)
        lines = int32(lines)

        vis=np.ones((h,w),)

        for (x1, y1), (x2, y2) in lines:
            cv.circle(vis, (x1, y1), 1, (0, 255, 0), -1)
            cv.arrowedLine(vis,(x1,y1),(x2,y2),color=(0,0,255),tipLength=1)
        return vis

    while(1):
        ret, frame2 = cap.read()
        next = cv.cvtColor(frame2, cv.COLOR_BGR2GRAY)
        h, w = next.shape[:2]

        flow = cv.calcOpticalFlowFarneback(prvs, next, None, 0.5, 3, 15, 3, 5, 1.2, 0)

        mag, ang = cv.cartToPolar(flow[..., 0], flow[..., 1])
        hsv[..., 0] = ang * 180 / np.pi / 2
        hsv[..., 2] = cv.normalize(mag, None, 0, 255, cv.NORM_MINMAX)
        rgb = cv.cvtColor(hsv, cv.COLOR_HSV2BGR)

        # plt=draw_flow(next, flow)
        # plt.show()
        f=open('./F/8/shuibo_8_Farneback(x,y,fx,fy).txt','w')
        vis = np.ones((h,w), )
        vis=draw_flow(next, flow)
        f.close()
        # cv.imshow('Gunnar Farneback', vis) 
        cv.imshow('Gunnar Farneback', rgb) 
        prvs = next
        if cv.waitKey(10) & 0xFF == ord('q'):
            break
    
    # The following frees up resources and closes all windows
    cap.release()
    cv.destroyAllWindows()

#def Mode6():


def Mode7():
    # The video feed is read in as a VideoCapture object
    cap = cv.VideoCapture("a.mp4")
    # ret = a boolean return value from getting the frame, first_frame = the first frame in the entire video sequence
    ret, first_frame = cap.read()
    # Converts frame to grayscale because we only need the luminance channel for detecting edges - less computationally expensive
    prev_gray = cv.cvtColor(first_frame, cv.COLOR_BGR2GRAY)
    # Creates an image filled with zero intensities with the same dimensions as the frame
    mask = np.zeros_like(first_frame)
    # Sets image saturation to maximum
    mask[..., 1] = 255

    while(cap.isOpened()):
        # ret = a boolean return value from getting the frame, frame = the current frame being projected in the video
        ret, frame = cap.read()
        # Opens a new window and displays the input frame
        cv.imshow("input", frame)
        # Converts each frame to grayscale - we previously only converted the first frame to grayscale
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        # Calculates dense optical flow by Farneback method
        flow = cv.calcOpticalFlowFarneback(prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        # Computes the magnitude and angle of the 2D vectors
        magnitude, angle = cv.cartToPolar(flow[..., 0], flow[..., 1])
        # Sets image hue according to the optical flow direction
        mask[..., 0] = angle * 180 / np.pi / 2
        # Sets image value according to the optical flow magnitude (normalized)
        mask[..., 2] = cv.normalize(magnitude, None, 0, 255, cv.NORM_MINMAX)
        # Converts HSV to RGB (BGR) color representation
        rgb = cv.cvtColor(mask, cv.COLOR_HSV2BGR)
        # Opens a new window and displays the output frame
        cv.imshow("dense optical flow", rgb)
        # Updates previous frame
        prev_gray = gray
        # Frames are read by intervals of 1 millisecond. The programs breaks out of the while loop when the user presses the 'q' key
        if cv.waitKey(1) & 0xFF == ord('q'):
            break
    # The following frees up resources and closes all windows
    cap.release()
    cv.destroyAllWindows()




class PyQtMainEntry(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
 
    def Feature1_Click(self):
        Mode1()
        
    def Feature2_Click(self):
        Mode2()
        
    def Feature3_Click(self):
        global coor_x,coor_y,coor
        Mode3()

    def Feature4_Click(self):
        global coor_x,coor_y,coor
        Mode4()    

    def Feature5_Click(self):
        global coor_x,coor_y,coor
        Mode5()

#    def Feature6_Click(self):
#        global coor_x,coor_y,coor
#        Mode6()

    def Feature7_Click(self):
        global coor_x,coor_y,coor
        Mode7()
        

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = PyQtMainEntry()
    window.show()
    sys.exit(app.exec_())
