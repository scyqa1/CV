#coding=utf-8
import numpy as np
import cv2
# from common import anorm2, draw_str
# from time import clock
import cmath

lk_params = dict(winSize=(15, 15),
                 maxLevel=2,
                 criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))

feature_params = dict(maxCorners=1000,
                      qualityLevel=0.1,
                      minDistance=7,
                      blockSize=7)

class App:
    def __init__(self, video_src):  
        self.track_len = 50
        self.detect_interval = 1
        self.tracks = []
        self.cam = cv2.VideoCapture(video_src)
        self.frame_idx = 0
        self.num = 0
        self.i = 0
        self.all_distance = 0
        self.count = 0

    def run(self):  
        while True:
            ret, frame = self.cam.read() 
            if ret == True:
                frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) 
                # vis = frame.copy()
                h, w = frame.shape[:2]
                # vis = np.ones((h, w), )
                # f = open('./F/8/shuibo_8_LK(x1,y1,x2,y2).txt','w')

                if len(self.tracks) > 0: 
                    img0, img1 = self.prev_gray, frame_gray
                    p0 = np.float32([tr[-1] for tr in self.tracks]).reshape(-1, 1, 2)

                    p1, st, err = cv2.calcOpticalFlowPyrLK(img0, img1, p0, None,
                                                           **lk_params) 
                    p0r, st, err = cv2.calcOpticalFlowPyrLK(img1, img0, p1, None,
                                                            **lk_params)  
                    d = abs(p0 - p0r).reshape(-1, 2).max(-1) 

                    good=d
                    new_tracks = []
                    for tr, (x, y), good_flag in zip(self.tracks, p1.reshape(-1, 2), good): 
                        if not good_flag:
                            continue
                        tr.append((x, y))
                        if len(tr) > self.track_len:
                            del tr[0]
                        new_tracks.append(tr)
                        cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
                    self.tracks = new_tracks 
                    # print(self.tracks[0])
                    # print(self.tracks[1])

                    distance = 0

                    for tr in self.tracks:
                        # tr[0]=list(tr[0])
                        # tr[1]=list(tr[1])
                        x1=tr[0][0]
                        y1=tr[0][1]
                        x2 = tr[1][0]
                        y2 = tr[1][1]

                        # f.writelines([ str(x1), ' ', str(y1), ' ', str(x2), ' ', str(y2),'\n'])
                        dis=cmath.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))
                        distance=distance+dis
                        
                    distance=distance/len(self.tracks)
                    self.all_distance=self.all_distance+distance
                    self.count=self.count+1

                # f.close()

                if self.frame_idx % self.detect_interval == 0:  
                    mask = np.zeros_like(frame_gray)  
                    mask[:] = 255  
                    for x, y in [np.int32(tr[-1]) for tr in self.tracks]:  
                        cv2.circle(frame, (x, y), 1, 0, -1)
                    cv2.polylines(frame, [np.int32(tr) for tr in self.tracks], False, (0,255,0))
                    p = cv2.goodFeaturesToTrack(frame_gray, mask=mask, **feature_params)  
                    if p is not None:
                        for x, y in np.float32(p).reshape(-1, 2):
                            self.tracks.append([(x, y)])  

                self.frame_idx += 1
                self.prev_gray = frame_gray
                # cv2.imshow('lk_track', vis)
                # cv2.imshow('lk_track', mask)
                cv2.imshow('lk_track', frame)

            ch = 0xFF & cv2.waitKey(1)
            if ch == 27:
                break


